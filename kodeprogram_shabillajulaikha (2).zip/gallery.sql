-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Feb 2024 pada 03.23
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gallery`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `AlbumID` int(11) NOT NULL,
  `NamaAlbum` varchar(255) NOT NULL,
  `Deskripsi` text NOT NULL,
  `TanggalDibuat` date NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `album`
--

INSERT INTO `album` (`AlbumID`, `NamaAlbum`, `Deskripsi`, `TanggalDibuat`, `UserID`) VALUES
(4, 'flowers', 'Kenangan bunga di tahun 2024', '2024-02-20', 5),
(5, 'Mobil', 'Mobil antik kesukaanku', '2024-02-20', 6),
(6, 'Jam Tangan Antik', 'Jam tangan hasil kerja kerasku', '2024-02-20', 6),
(7, 'Pramuka', 'Pramuka adalah rumah keduaku', '2024-02-20', 7),
(8, 'minggu', 'sangat enak', '2024-02-21', 8),
(13, 'pohon', 'lama', '2024-02-20', 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `FotoID` int(11) NOT NULL,
  `JudulFoto` varchar(255) NOT NULL,
  `DeskripsiFoto` text NOT NULL,
  `TanggalUnggah` date NOT NULL,
  `LokasiFile` varchar(255) NOT NULL,
  `AlbumID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `foto`
--

INSERT INTO `foto` (`FotoID`, `JudulFoto`, `DeskripsiFoto`, `TanggalUnggah`, `LokasiFile`, `AlbumID`, `UserID`) VALUES
(6, 'Matahari', 'Bunga Matahari selalu seiras dengan warna kuning', '2024-02-20', 'public/images/HtUWH4gkHB6u5qowJW4SXwzd5BHjF0UpCbtvALvU.jpg', 4, 5),
(7, 'Disney', 'Bunga ini kutemukan dirumah temanku', '2024-02-20', 'public/images/QWwQa7qxaTZYxd1DATd5yhUyV8BGlxLfVzYRUJ2X.jpg', 4, 5),
(8, 'Mawar', 'bunga ini sangat harum sekali', '2024-02-20', 'public/images/C3CUVjQSyiooGYBJxMsBqqeUcsB8Z6caltPGM8Cu.jpg', 4, 5),
(9, 'Mobil', 'Tahun ini dibelikan oleh ayahku hadiah ulang tahun ke18 tahun', '2024-02-20', 'public/images/V7U3aNFsG9PSeLjNUXXFOw5lyESrC70kkhGHfiEM.jpg', 5, 6),
(11, 'mobil', 'Tahun ini umurku 20tahun,saya membelikan mobil baru untuk ayah', '2024-02-20', 'public/images/Jc7EiKPAWv4LdQxY0RAOZrtUl4g5fOf6dEoBc1gI.jpg', 5, 6),
(13, 'jam nenek', 'nenek memberikanku jam tangan antik disaat umurku sudah 15tahun', '2024-02-20', 'public/images/xSob99jrLWS7mfbOmc2aIlazhlPFQgsQqt2maINm.jpg', 6, 6),
(14, 'jam tangan ayah', 'ayah memberikanku jam tangan sebagai hadiah sweetseventenku', '2024-02-20', 'public/images/J72lmXp1356kj1oOPH1E4BSx9Oe4Agqj63XkdEgT.jpg', 6, 6),
(15, 'Api unggun', 'api unggun ini menjadi rutinitas anak pramuka setiap acara perkemahan dimalam minggu', '2024-02-20', 'public/images/QcFlTqA42rfArTjH3dGvEe8aR23MQNelbdxqox41.jpg', 7, 7),
(16, 'Perjusami', 'Perkemahan jumat sabtu dan minggu', '2024-02-20', 'public/images/9ufJ1z4AeUqhA8NT7GCgB9H3slSOrbE7fQVKzUun.jpg', 7, 7),
(27, 'matahari', 'hallo ges', '2024-02-21', 'public/images/BXkeITZdL5D1WtiNh5QxLHfL5Vh1W0tdc8dyV8wW.jpg', 8, 8),
(28, 'antik', 'mobil akkek', '2024-02-21', 'public/images/PfqrhlRqmRvRqNuCsnCrG2JBwsugcTNM7C0W5stB.jpg', 8, 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `KomentarID` int(11) NOT NULL,
  `FotoID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `IsiKomentar` text NOT NULL,
  `TanggalKomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `komentarfoto`
--

INSERT INTO `komentarfoto` (`KomentarID`, `FotoID`, `UserID`, `IsiKomentar`, `TanggalKomentar`) VALUES
(1, 18, 8, 'wah asli si seruu banget', '2024-02-20'),
(2, 20, 8, 'wahhh ini asli', '2024-02-20'),
(3, 28, 8, 'hallo guys', '2024-02-21');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likefoto`
--

CREATE TABLE `likefoto` (
  `LikeID` int(11) NOT NULL,
  `FotoID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `TanggalLike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `likefoto`
--

INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES
(1, 18, 8, '2024-02-20'),
(2, 17, 8, '2024-02-20'),
(3, 8, 8, '2024-02-20'),
(4, 6, 8, '2024-02-20'),
(5, 20, 8, '2024-02-20'),
(6, 20, 10, '2024-02-20'),
(7, 10, 14, '2024-02-20'),
(8, 21, 10, '2024-02-21'),
(9, 28, 8, '2024-02-21');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `NamaLengkap` varchar(255) NOT NULL,
  `Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`) VALUES
(5, 'julaikha', '190607', 'julaikha@gmail.com', 'Julaikha Shabilla', 'Tegal Rejo RT 14'),
(6, 'kenzie', '170421', 'kenziealfaresqy@gmail.com', 'kenzie alfaresqy', 'Tegal Rejo RT 14'),
(7, 'aftar', '050406', 'aftarsyahbilillah@gmail.com', 'Aftar Syahbilillah Putra', 'Talang Jawa'),
(8, 'billa', '190607', 'shabilla@gmail.com', 'shabilla julaikha', 'BTN Mandala sebrang uluan'),
(9, 'sekolah', '12345', 'sekolah@gmail.com', 'smk bukit asam', 'talang jawa'),
(10, 'pasar', '90', 'pasar@gmail.com', 'pasar murah', 'tegal rejo'),
(11, 'cintah', '123', 'pasti bisaa', 'aku kan ada', 'rt 02'),
(12, 'cintah', '123', 'pasti bisaa', 'aku kan ada', 'rt 02'),
(13, 'haluu', 'oo', 'pasti bisaa', 'aku kan ada', 'rt 02'),
(14, 'paku', 'payung', 'paku@gmail.com', 'paku payung', 'besi'),
(15, 'jj', 'jkl', 'aaa', 'ssss', 'ddd'),
(16, 'jj', 'jkl', 'aaa', 'ssss', 'ddd'),
(17, 'jj', 'jkl', 'aaa', 'ssss', 'ddd'),
(18, 'jj', 'jkl', 'aaa', 'ssss', 'ddd'),
(19, 'jj', 'jkl', 'aaa', 'ssss', 'ddd'),
(20, 'jj', 'jkl', 'aaa', 'ssss', 'ddd'),
(21, 'oke', '34', 'aaa', 'ssss', 'ddd'),
(22, 'siap', 'jj', 'aaa', 'ssss', 'ddd'),
(23, 'siap', 'kalo', 'aaa', 'ssss', 'ddd'),
(24, 'siap', 'ih', 'aaa', 'ssss', 'ddd'),
(25, 'cantik', 'asd', 'cantika.gmail.com', 'cantikaputri', 'mandala'),
(26, 'pohon', 'hj', 'jjk', 'kk', 'xx');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`);

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`FotoID`);

--
-- Indeks untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`KomentarID`);

--
-- Indeks untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`LikeID`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `AlbumID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `FotoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `KomentarID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `LikeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
