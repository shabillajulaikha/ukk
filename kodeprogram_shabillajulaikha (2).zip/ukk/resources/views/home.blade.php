<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>

      /* ini navbar */
  header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background:  #AAD7D9;
  }

  .navigation a {    
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 150px;
  }

  .b a {
    position: relative;
    color: black;
    text-decoration: none;
    font-weight: 600;
  }
  .c a {
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
  }
/* selesai */
     </style>
</head>
<body style="background-color: #FFF78A !important;">
<main>
  <!-- ini navbar -->
  <header class="p-3 text-bg-dark" style="background-color :#FFB534 !important;">
  <!-- kode dibawah menampilkan ikon kembali (back) yang mengarahkan pengguna ke halaman sebelumnya saat ikon tersebut diklik. -->
  <a href="javascript:history.go(-1)" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
        </svg>
        </a>
      <nav class="b">
      <a href="#" class="nav-link px-2 text-light" style="font-family: 'Georgia', serif; font-size: 25px; font-weight: bold; text-decoration: none; color: #3498db; text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.5);">
          Website Gallery Foto {{ Session()->get('user')->Username }}
        </a>
      </nav>
      <!-- selesai -->
      <!-- ini button -->
        <div class="text-end">
        <a href="/album" button type="button" class="btn btn-outline-light me-2" style="font-family: 'Georgia'">Collection {{(Session()->get('user')->Username)}}</button></a>
        <a href="/layar" button type="button" class="btn btn-outline-light me-2" style="font-family: 'Georgia'">Logout</button></a>
        </div>
        <!-- selesai -->
  </header>
  <!-- ini untuk mengambil file foto -->
  @include('foto')
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>   
</body>
</html>