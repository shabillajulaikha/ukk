<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
    /* ini navbar */
    header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background:  #AAD7D9;
    }

     .navigation a {    
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 150px;
    }

    .b a {
    position: relative;
    color: black;
    text-decoration: none;
    font-weight: 600;
    }
    .c a {
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
     }
/* selesai */
        /* ini untuk deskripsinya */
        :root{
            --prime-color:#FFB534;
            --hover-color:red;
        }
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
        }
        body{
            background: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items:center;
            min-height: 100vh;
        }
        .card{
            width: 280px;
            height: 280px;
            background: #fff;
            border-radius: 30px;
            position: relative;
            transition: 0.5s ease-in-out;
            overflow: hidden;
        }
        .profile-pic{
            position:absolute;
            width:100%;
            height:100%;
            top:0;
            left:0;
            border-radius: 30px;
            z-index: 1;
            border: 5px solid #fff;
            overflow: hidden;
            transition: 0.5s ease-in-out;
        }
        .profile-pic-img{
            width:100%;
            height:100%;
            object-fit: cover;
            position: relative;
            top:0;
            transition:0.5s ease-in-out;
        }
        .card:hover .profile-pic{
            width: 100px;
            height: 100px;
            top: 10px;
            left: 10px;
            border-radius: 50%;
            z-index: 3;
            border: 5px solid var(--prime-color);
            box-shadow: 0 0 10px #1115;
            transition: 0.5s ease-in-out;
        }
        .card:hover .profile-pic img{
            transform: scale(1.6);
            top: 20px;
            transition: 0.5s ease-in-out;
        }
        .details{
            position: absolute;
            left: 4px;
            right: 4px;
            bottom: 4px;
            z-index: 2;
            top: 360px;
            background: var(--prime-color);
            color: #fff;
            border-radius: 25px;
            overflow: hidden;
            box-shadow: inset 5px 5px 10px #1114;
            transition: 0.5s ease-in-out;
        }
        .card:hover .details{
            top:20px;
            border-radius: 80px 25px 25px 25px;
            transition: 0.5s ease-in-out 0.25;
        }
        .content{
            position: absolute;
            top:-300px;
            left: 20px;
            opacity: 0;
            transition: 0.5s ease-in-out 0s;
        }
        .card:hover .content{
            top: 10px;
            opacity: 1;
            transition: 0.5s ease-in-out 0.5s;
        }
        .content h2{
            margin-left: 130px;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .content .tag{
            margin-left: 130px;
            font-size: .6rem;
            font-weight: 200;
            letter-spacing: 2px;
        }
        .content .about{
            font-size: 0.8rem;
            margin-top: 40px;
            width: 80%;
        }
        .buttons{
            position: absolute;
            bottom:12px;
            width: 100%;
            padding: 0 20px;
            display: flex;
            justify-content:space-between;
            align-items: center;
        }
        .buttons .social{
            display: flex;
            gap: 15px;
        }
        .buttons .social i{
            color: #fff;
            cursor: pointer;
        }
        .buttons .social i:hover{
            color: var(--hover-color);
        }
        .buttons .link:hover{
            background:var(--hover-color);
        }  
         /* untuk mengatur icon */ */
         .big-icon {
        font-size: 2rem; 
        }

        /* untuk inputan css */
        #uname {
        font-family: Arial, sans-serif;
        font-size: 16px;
        color: #333; 
        border: 2px solid #ccc; 
        border-radius: 5px; 
        padding: 10px; 
        width: 300px;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1); 
        }

        .like-btn-container {
        display: flex;
        align-items: center; 
        }

         .bi-heart-fill.big-icon {
        margin-top: 0; 
        margin-right: 5px; 
        }
    </style>
</head>
<body style="background-color :#FFF78A !important">
  <!-- ini navbar -->
  <header class="p-3 text-bg-dark" style="background-color :#FFB534 !important;">
  <!-- kode dibawah menampilkan ikon kembali (back) yang mengarahkan pengguna ke halaman sebelumnya saat ikon tersebut diklik. -->
  <a href="javascript:history.go(-1)" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
        </svg>
        </a>
      <nav class="b">
      <a href="#" class="nav-link px-2 text-light" style="font-family: 'Georgia', serif; font-size: 25px; font-weight: bold; text-decoration: none; color: #3498db; text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.5);">
          Website Gallery Foto {{ Session()->get('user')->Username }}
        </a>
      </nav>
      <!-- selesai -->
  </header>
    <!-- selesai -->
    <div class="card" style="width: 450px; height: 450px;" >
        <div class="profile-pic" >
             <img src="{{Storage::url($item->LokasiFile)}}" alt="">
        </div>
        <div class="details" >
        <div class="content">
             <h2 style="font-size:1.2em; color: white; font-family: 'Arial Black', Arial, sans-serif;">{{$item->JudulFoto }}</h2>
             <h3 class="tag" style="font-size:0.9em; color: red; font-family: 'Georgia', Arial, sans-serif; font-weight: bold;">
             User : @if($nama = $user->where('UserID', $item->UserID)->first()){{$nama->NamaLengkap}}
             @endif
            </h3>
             <h4 class="tag" style="font-size:0.9em; font-family: 'Georgia', Arial, sans-serif; font-weight: bold;">{{$item->DeskripsiFoto }}</h4>
        </div>
    <!-- ISI KOMENTAR -->
    <div class="text-start ps-5" style="margin-top: 20vh;">
    @foreach($komentar as $komen)
    <div class="mb-2">
        <div class="fw-bold text-muted" style="color: red; font-family: 'Gill Sans', 'Gill Sans MT'; font-weight: 700;">
        {{ \App\Models\User::where('UserID',$komen->UserID)->first()->Username }}
        <span class="fw-bolder" style="font-size: 13px;">{{ $komen->TanggalKomentar}}</span></div>
        <span class="fw-bolder">{{$komen->IsiKomentar}}</span>
        </div>
     @endforeach
     </div>
    <div class="buttons">
    <!-- LIKE -->
        <div class="social">
            <form action="/like/{{$item->FotoID}}" method="post">
            @csrf
            @if ($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $item->FotoID)->first())
            <div class="like-btn-container">
                <button class="btn rounded-pill px-3" style="background: none; border:none;" type="submit"><i class="bi bi-heart-fill big-icon" style="color: red; font-size: 25px; margin-top: 50px; "></i></button>
                {{$like->where('FotoID', $item->FotoID)->count() }}
            @else
                <button class="btn rounded-pill px-3" style="background: none; border:none;" type="submit"><i class="bi bi-heart-fill big-icon" style="color: white; font-size: 25px; margin-top: 50px; "></i></button>
                {{$like->where('FotoID', $item->FotoID)->count()}}
            @endif
            </div>
            </form>
        </div>
    <!-- KOMENTAR -->
        <div class="pt-3">
            <form action="/komen/{{$item->FotoID}}" method="post">
            @csrf
                <input id="uname" class="form-control me-2 shadow-sm rounded-pill" type="text" name="komentar" placeholder="Masukkan Komentar"> 
            </form>
            </div>
        </div>   
</body>
</html>