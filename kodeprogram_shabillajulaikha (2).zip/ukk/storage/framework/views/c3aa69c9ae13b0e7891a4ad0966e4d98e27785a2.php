<!doctype html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collection</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
    /* ini navbar */
    header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background:  #AAD7D9;
    }

     .navigation a {    
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 150px;
    }

    .b a {
    position: relative;
    color: black;
    text-decoration: none;
    font-weight: 600;
    }
    .c a {
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
     }
/* selesai */ 

/* ini my album */
  *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family:sans-serif;
      }
      .container{
        width: 100%;
        text-align: center;
      }
       
      label{
        display: inline-block;
        height: 100%;
        padding: 0 20px;
        margin: 0 60px;
        line-height: 60px;
        font-size: 18px;
        color: black;
        cursor: pointer;
        transition: color .5s;
      }
      label:hover{
        color: red;
      }
      .photo-gallery{
        width: 90%;
        margin: auto;
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-gap: 20px;
      }
      .grid{
             display: grid;
             grid-template-columns: repeat(4, 1fr); 
             /* grid-template-columns: repeat(4, 1fr); */
             margin: 0px;
             align-items: center;
             grid-gap: 30px;
        }
        img{
            object-fit: cover;
        }
        .grid > article{
            box-shadow: 10px 5px 5px 0px black;
            border-radius: 20px;
            text-align: center;
            background: rgb(214, 210, 206);
            width: 250px;
            transition: transform;
            margin-top: 60px;
        }
        .grid  article img{
            border-top-left-radius: 30px;
            border-top-right-radius: 30px; width: 100%;
        }
      
        @media (max-width:1300px){
            .grid{
                grid-template-columns: repeat(2,1fr);
            }
        }
        @media (max-width:1300px){
            .grid{
                grid-template-columns: repeat(2,1fr);
            }
        }
  
      .container{
        width: 100%;
        text-align: center;
      }
      h1{
        font-weight: normal;
        font-size: 35px;
        position: relative;
        margin: 40px 0;
      }
      h1::before{
        content: '';
        position: absolute;
        width: 100px;
        height: 3px;
        background-color: crimson;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        animation: animate 4s linear infinite;
      }
      @keyframes animate{
        0%{
          width: 100px;
        }
        50%{
          width: 200px;
        }
        100%{
          width: 100px;
        }
      }
      /* selesai */
</style>
</head>
<body style="background-color: #FFF78A !important;">
<main>
  <!-- ini navbar -->
  <header class="p-3 text-bg-dark" style="background-color :#FFB534 !important;">
  <!-- kode dibawah menampilkan ikon kembali (back) yang mengarahkan pengguna ke halaman sebelumnya saat ikon tersebut diklik. -->
  <a href="javascript:history.go(-1)" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
        </svg>
        </a>
      <nav class="b">
      <a href="#" class="nav-link px-2 text-light" style="font-family: 'Georgia', serif; font-size: 25px; font-weight: bold; text-decoration: none; color: #3498db; text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.5);">
          Website Gallery Foto <?php echo e(Session()->get('user')->Username); ?>

        </a>
      </nav>
      <!-- selesai -->
      <!-- ini button -->
      <div class="text-end">
        <!-- <a href="/album" button type="button" class="btn btn-outline-light me-2" style="font-family: 'Georgia'">Collection <?php echo e((Session()->get('user')->Username)); ?></button></a>
        <a href="/layar" button type="button" class="btn btn-outline-light me-2" style="font-family: 'Georgia'">Logout</button></a> -->
        </div>
        <!-- selesai -->
  </header>
    <br> 
    <br>
    <br>
    <div class="btn d-flex gap-4 justify-content-center text-end">
      <span class="badge d-flex p-2 align-items-right text-primary-emphasis bg-light-subtle rounded-pill">
        <span class="px-1">tambah foto</span>
        <a href="/tambah" class="text-primary-emphasis"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
        </svg></a>
      </span>
       <span class="badge d-flex p-2 align-items-right text-primary-emphasis bg-light-subtle rounded-pill">
        <span class="px-1">tambah album</span>
        <a href="/tambum" class="text-primary-emphasis"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4"/>
        </svg></a>
      </span>
    </div>
<!-- selesai -->

<!-- ini untuk my album -->
<div class="container">
<h1 style="font-family: Georgia;">My Album Gallery</h1>
<?php $__currentLoopData = $bebas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class = "container">
        <main class = "grid">
            <article style="background-color:#FFB534">
                <a href="/album<?php echo e($item->AlbumID); ?>"><img src = "gambar/e.png" width="200px" height="200px"></a>
                <div class = "konten" style="background-color:#FFB534">
                    <h4 style="color: white; font-family:georgia;"><?php echo e($item->NamaAlbum); ?></h4>
                    <p style="color: white; font-family:georgia;"><?php echo e($item->Deskripsi); ?></p>
                    <p style="color: white; font-family:georgia;"><?php echo e($item->TanggalDibuat); ?></p>
                    <!-- ini hapus -->
                    <a href="/hapusdata/<?php echo e($item->AlbumID); ?>">
                         <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16" style="vertical-align: middle; margin-top: -16px; color: red; margin-right: 5px;">
                         <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5M8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5m3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0"/>
                         </svg>
                    </a>
                    <!-- selesai -->
                     <!-- ini edit -->
                      <a href="/editbum/<?php echo e($item->AlbumID); ?>">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-pen-fill" viewBox="0 0 16 16" style="vertical-align: middle; margin-top: -16px; color: black; margin-left: 5px;">
                      <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001"/>
                      </svg></a>
                      <!-- selesai -->
                </div> 
            </article>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <!-- selesai -->
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body> 
</html>
</body><?php /**PATH C:\Users\ASUS\ukk\resources\views/album.blade.php ENDPATH**/ ?>