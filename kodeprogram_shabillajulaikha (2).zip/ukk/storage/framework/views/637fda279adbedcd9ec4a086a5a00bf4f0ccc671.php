<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;  
  }
  body{
    background-image: url('img/b.svg');
  }
  .container {
    width: 1200px;
    margin: 20px auto;
    columns: 4;
    column-gap: 20px;
    margin-top: 100px; 
}
.container .photo {
    width: 100%;
    margin-bottom: 10px;
    break-inside: avoid;
}

.container .photo img {
    max-width: 100%;
    border-radius: 10px;
}

@media (max-width: 1200px)
{
    .container {
        width: calc(100% - 40px);
        columns: 3;
    }
}

@media (max-width: 768px)
{
    .container{
        columns: 2;
    }
}

@media (max-width: 480px)
{
    .container {
        columns: 1;
    }
}
</style>
</head>
<body>
  <div class="container">
  <?php $__currentLoopData = $bebas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="photo">
    <a href="/deskripsi/<?php echo e($item->FotoID); ?>"><img src="<?php echo e(Storage::url($item->LokasiFile)); ?>"></a></div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  </div>  
</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\ASUS\ukk\resources\views/foto.blade.php ENDPATH**/ ?>