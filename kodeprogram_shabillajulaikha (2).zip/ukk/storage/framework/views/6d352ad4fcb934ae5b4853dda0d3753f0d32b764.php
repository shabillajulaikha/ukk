<!doctype html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
    /* ini navbar */
    header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background:  #AAD7D9;
    }

     .navigation a {    
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 150px;
    }

    .b a {
    position: relative;
    color: black;
    text-decoration: none;
    font-weight: 600;
    }
    .c a {
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
     }
/* selesai */
    /* ini body registrasi */
    body{
      background-size: cover;: fixed}#particles-js{height: 100%}
      .loginBox{position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%);width: 350px;min-height: 200px;background:#FFB534;border-radius: 10px;padding: 40px;box-sizing: border-box}.user{margin: 0 auto;display: block;margin-bottom: 20px}h3{margin: 0;padding: 0 0 20px;color:#9AD0C2;text-align: center}.loginBox input{width: 100%;margin-bottom: 20px}.loginBox input[type="text"], .loginBox input[type="password"]{border: none;border-bottom: 2px solid white;outline: none;height: 40px;color:white;background: transparent;font-size: 16px;padding-left: 20px;box-sizing: border-box}.loginBox input[type="text"]:hover, .loginBox input[type="password"]:hover{color:white;border: 1px solid #fff;box-shadow: 0 0 5px rgba(0,0,0,.3), 0 0 10px rgba(0,0,0,.2), 0 0 15px rgba(0,0,0,.1), 0 2px 0 black}.loginBox input[type="text"]:focus, .loginBox input[type="password"]:focus{border-bottom: 2px solid white}.inputBox{position: relative}.inputBox span{position: absolute;top: 10px;color:}.loginBox input[type="submit"]{border: none;outline: none;height: 40px;font-size: 16px;background: #FFB534;color: #fff;border-radius: 20px;cursor: pointer}.loginBox a{color: #9AD0C2;font-size: 14px;font-weight: bold;text-decoration: none;text-align: center;display: block}a:hover{color: #9AD0C2}p{color: #9AD0C2}
    /* selesai */

    /* mengatur jarak navbar dan body register */
      .loginBox {
      margin-top: 70px; 
     }

    /* untuk mengatur font */
          input[type="submit"] {
        font-weight: bold;
    }
    </style>
    <link href="headers.css" rel="stylesheet">
    </head>
    <body style="background-color: #FFF78A !important;">
    <!-- ini navbar -->
    <main>
        <header class="p-3 text-bg-dark" style="background-color:#FFB534 !important;">
            <!-- kode dibawah menampilkan ikon kembali (back) yang mengarahkan pengguna ke halaman sebelumnya saat ikon tersebut diklik. -->
        <a href="javascript:history.go(-1)" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
        </svg>
        </a>
            <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                
        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
        <li class="nav-item">
        <a href="#" class="nav-link px-2 text-light" style="font-family: 'Georgia', serif; font-size: 25px; font-weight: bold; text-decoration: none; color: #3498db; text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.5);">
          Website Gallery Foto</a>
        </li>
        </ul>
        </header>
    </main>
    <!-- selesai -->

    <!-- form registrasi -->
    <div class="loginBox"> <img class="user" src="https://i.ibb.co/yVGxFPR/2.png" height="30px" width="30px">
    <h4 style="color:white; font-family: Arial Black;">Daftarkan Diri Anda!</h4>
    
            <form action="/login" method="post">
            <?php echo csrf_field(); ?>
                <div class="inputBox" style="color: info">  
                <input id="username" type="text" name="Username" placeholder="Username" required>
                <div style="position:relative;">
                  <input type="password" name="Password" id="password" placeholder="Password" required>
                    <svg xmlns="http://www.w3.org/2000/svg" width="23" height="23" fill="currentColor" class="bi bi-eye-slash-fill" viewBox="0 0 16 16" style="position:absolute;right:10px;top:50%;transform:translateY(-50%); color:white; margin-top: -16px;" onclick="togglePasswordVisibility()">
                    <path d="m10.79 12.912-1.614-1.615a3.5 3.5 0 0 1-4.474-4.474l-2.06-2.06C.938 6.278 0 8 0 8s3 5.5 8 5.5a7 7 0 0 0 2.79-.588M5.21 3.088A7 7 0 0 1 8 2.5c5 0 8 5.5 8 5.5s-.939 1.721-2.641 3.238l-2.062-2.062a3.5 3.5 0 0 0-4.474-4.474z"/>
                    <path d="M5.525 7.646a2.5 2.5 0 0 0 2.829 2.829zm4.95.708-2.829-2.83a2.5 2.5 0 0 1 2.829 2.829zm3.171 6-12-12 .708-.708 12 12z"/>
                    </svg>
                </div> 
                <script>
                    function togglePasswordVisibility() {
                        var passwordInput = document.getElementById("password");

                        if (passwordInput.type === "password") {
                            passwordInput.type = "text";
                        } else {
                            passwordInput.type = "password";
                        }
                        }
                </script>
                <input id="email" type="text" name="Email" placeholder="Alamat Gmail" required>
                <input id="nama" type="text" name="Nama" placeholder="Nama Lengkap"required> 
                <input id="alamat" type="text" name="Alamat" placeholder="Alamat"required>
                </div> 
            <input type="submit" name="" value="Daftar" style="color:white;, font-family: Arial Black;" >
            </form> 
        </div>
        <!-- selesai -->
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body> 
</html><?php /**PATH C:\Users\ASUS\ukk\resources\views/register.blade.php ENDPATH**/ ?>