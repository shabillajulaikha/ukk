<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambahkan Foto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
     /* ini navbar */
    header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    padding: 20px 100px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 99;
    background:  #AAD7D9;
    }

     .navigation a {    
    color: black;
    text-decoration: none;
    font-weight: 600;
    margin-left: 150px;
    }

    .b a {
    position: relative;
    color: black;
    text-decoration: none;
    font-weight: 600;
    }
    .c a {
    position: relative;
    font-size: 1.1em;
    color: black;
    text-decoration: none;
    font-weight: 600;
     }
    /* selesai */

    /* ini form tambah album */
    .kuning-bg {
        background-color:#FFB534; 
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-50px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .fade-in {
        animation: fadeIn 1s ease-out;
    }
    .row {
    margin-top: 1%  ;   
    }
    .card-body {
    box-shadow: 0 0 10px style="background-color:#191970";
    margin: 35px;
    }
    /* selesai */
    </style>
</head>
<body style="background-color: #FFF78A !important;">
    <!-- ini navbar -->
    <main>
        <header class="p-3 text-bg-dark" style="background-color:#FFB534 !important;">
        <!-- kode dibawah menampilkan ikon kembali (back) yang mengarahkan pengguna ke halaman sebelumnya saat ikon tersebut diklik. -->
        <a href="javascript:history.go(-1)" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z"/>
        </svg>
        </a>
            <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
                <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"/></svg>
                </a>
        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
        <li class="nav-item">
        <a href="#" class="nav-link px-2 text-light" style="font-family: 'times new roman', sans-serif; font-size: 25px; font-weight: bold; text-decoration: none; color: #3498db;">
        Website Gallery Foto <?php echo e(Session()->get('user')->Username); ?>

        </a>
        </li>
        </ul>
        </header>
    </main>
    <!-- selesai -->
    
    <!-- ini form tambah album -->
    <div class="container mt-5 pt-5">
            <div class="row">
                <div class="col-18 col-sm-12 col-md-9 m-auto">
                    <div class="card border-0 shadow shadow kuning-bg fade-in">
                    <div class="card-body text-center"> <!-- Center align the content -->
                    <label for="tambahFoto" class="form-label text-light" style="font-family: 'Montserrat'; font-size: 24px;">Tambah Album</label>
                    <form action="/editAlbum/<?php echo e($item['album']->AlbumID); ?>" Method="POST" class="form" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="namaalbum" class="form-control my-4 py-2" placeholder="Nama Album">
                                <input type="text" name="deskripsialbum" class="form-control my-4 py-2" placeholder="Deskripsi">  
                                <div class="text-center mt-3">   
                                <input type="submit" value="TAMBAH" class="btn btn-primary" style="font-family: 'times new roman'">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        <!-- selesai -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>   
</body>
</html><?php /**PATH C:\Users\ASUS\ukk\resources\views/editbum.blade.php ENDPATH**/ ?>