<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <title>SISWA</title>
</head>
<body>
    <a href="/siswa/tambah">TAMBAH SISWA</a>
<table border="1" class="table table-striped">
    <thead>
        <tr class="table-danger">
            <th>Nomor Urut</th>
            <th>Nama Siswa</th>
            <th>Jenis Kelamin</th>
            <th>Aksi</th>
</tr>
</thead>
<tbody>
    <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr> 
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($siswa->nama); ?></td>
        <td><?php echo e($siswa->jenis_kelamin); ?></td>
        <td> 
            <a href="/siswa/edit/<?php echo e($siswa->id); ?>"> Edit </a>
            <a href="/siswa/hapus/<?php echo e($siswa->id); ?>"> Hapus </a> 
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
    </table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\ASUS\ukk\resources\views/siswa/index.blade.php ENDPATH**/ ?>