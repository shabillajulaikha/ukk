<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
</head>
<body>
    <form action="/siswa/edit/<?php echo e($siswa->id); ?>" method="POST">
        <?php echo csrf_field(); ?> 
        <input type="text" name="nama" value="<?php echo e($siswa->nama); ?>">
        <select name="jenis_kelamin">
            <option value="1" <?php if($siswa->jenis_kelamin == 'l'): ?> selected <?php endif; ?>>Laki - Laki</option>
            <option value="p" <?php if($siswa->jenis_kelamin == 'p'): ?> selected <?php endif; ?>>Perempuan</option>
</select>
<input type="submit" value="SIMPAN">
<form>
</body>
</html><?php /**PATH C:\Users\ASUS\ukk\resources\views/siswa/edit.blade.php ENDPATH**/ ?>