<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Siswa</title>
</head>
<body>
    <form action="/siswa/tambah/" method="POST">
        <?php echo csrf_field(); ?>
        Nama Siswa:<input type="text" name="nama"><br>
        <select name="jenis_kelamin">
            <option value="l">Laki - Laki</option>
            <option value="p">Perempuan</option>
</select>
<input type="submit" value="SIMPAN">
</form>
</body>
</html><?php /**PATH C:\Users\ASUS\ukk\resources\views/siswa/tambah.blade.php ENDPATH**/ ?>