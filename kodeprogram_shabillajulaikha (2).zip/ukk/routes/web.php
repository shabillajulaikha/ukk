<?php
use App\Http\controllers\GalleryController;
use Illuminate\Support\Facades\Route;
use App\Models\User;
use App\Models\Foto;
use App\Models\Album;
use App\Models\Like;
use App\Models\Komentar;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/layar', function () {
    return view('layar');
});

// ini view home
Route::get('/home', function () {
    $bebas = Foto::all();
    return view('home', compact('bebas'));
});

// ini routes view register
Route::get('/register', function () {
    return view('register');
});

// ini aksi register
Route::post('/login', [GalleryController::class,'aksiregister']);

// ini view login
Route::get('/login', function () {
    return view('login');
});

// ini aksi login
Route::post('/beranda', [GalleryController::class,'aksilogin']);

// ini view beranda
Route::get('/beranda', function () {
    return view('beranda');
});

// ini view album
Route::get('/album', function () {
    $bebas = Album::where('UserID', session('user')->UserID)->get();
    return view('album',compact('bebas'));
});

// ini view tambah album
Route::get('/tambum', function () {
    return view('tambahalbum');
});

// ini view aksi tambah album
Route::post('/album', [GalleryController::class,'aksialbum']); 

// ini view dan aksi tambah foto
Route::get('/tambah', [GalleryController::class,'view']);
Route::post('/home', [GalleryController::class,'aksifoto']);

// ini view lihat album
Route::get('/lihatalbum', function () {
    $bebas = Foto::where('UserID', session('user')->UserID)->get();
    return view('lihatalbum',compact('bebas'));
});

// ini mengambil foto id ke album
Route::get('/album{FotoID}', [GalleryController::class,'lihatalbum']);

// ini view deskripsi
Route::get('/deskripsi/{FotoID}', function ($FotoID) {
    $item = Foto::where('FotoID', $FotoID)->first();
    $like = Like::where('FotoID', $FotoID)->get();
    $komentar = Komentar::where('FotoID', $FotoID)->get();
    $user = User::All();
    return view('deskripsi', compact('item', 'like', 'komentar','user'));
});

// ini untuk aksi like
Route::post('/like/{FotoID}', [GalleryController::class, 'like']);

// ini untuk aksi komentar
Route::post('/komen/{FotoID}', [GalleryController::class, 'barukomen']);

// ini untuk hapus album
Route::get('/hapusdata/{AlbumID}',[GalleryController::class,'hapusdata']);

// ini untuk edit album
Route::get('/editbum/{AlbumID}',[GalleryController::class,'editbum']);
Route::post('/editAlbum/{AlbumID}',[GalleryController::class,'editAlbum']);

// ini untuk hapus foto
Route::get('/hapusfoto/{FotoID}',[GalleryController::class,'hapusfoto']);

// ini untuk edit foto
Route::get('/editdata/{FotoID}',[GalleryController::class,'editdata']);
Route::post('/editAksi/{FotoID}',[GalleryController::class,'editAksi']);



