<?php
return [
    'required' => 'Kolom :attribute harus diisi.',
    'email' => 'Kolom :attribute harus berupa alamat email yang valid.',
    // Tambahkan pesan validasi kustom untuk setiap aturan validasi lainnya
];