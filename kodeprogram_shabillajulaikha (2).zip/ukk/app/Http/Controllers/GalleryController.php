<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Like;
use App\Models\Komentar;

class GalleryController extends Controller
{
    //ini aksi registrasi
    public function aksiregister (Request $request){
        $data = new User();
        $data->Username = $request['Username'];
        $data->Password = $request['Password'];
        $data->Email =  $request['Email'];
        $data->NamaLengkap = $request['Nama'];
        $data->Alamat =$request['Alamat'];
        $data->save(); 
    
        return redirect('/login')->with('success', 'Registrasi berhasil. Silakan login.');
    }

     // ini aksi login
     public function aksilogin(Request $request){
        $data = User::where('Username', $request-> input ('Username'))->where('Password', $request-> input ('Password'))->first();
        if($data != null){
            session()->put('user', $data);
            return redirect('/home');
        }else{
            return redirect()->back()->with('pesan','Username / Password Salah!!');
        }
    }
    // ini aksi  tambah album
    public function aksialbum (Request $request){
        $data = new Album();
        $data->NamaAlbum =$request->input('namaalbum');
        $data->Deskripsi =$request->input('deskripsialbum'); 
        $data->TanggalDibuat=  date('Y-m-d');
        $data->UserID =session('user')->UserID;
        $data->save(); 
        return redirect('/album');
    } 

     // ini aksi upload foto
     public function view(){
        $bebas = Album::where('UserID', session('user')->UserID)->get();
        return view('tambahfoto', compact('bebas'));
    }
        public function aksifoto (Request $request){
            if ($request->hasFile('lokasifile')) {
             
                $locate = $request->file('lokasifile')->store('public/images');
    
                $data = new Foto();
                $data->JudulFoto = $request->input('judulfoto');
                $data->DeskripsiFoto = $request->input('deskripsifoto');
                $data->TanggalUnggah = date ('Y-m-d');
                $data->LokasiFile = $locate;
                $data->AlbumID = $request->get('album');
                $data->UserID = session('user')->UserID;
                
                $data->save();
                return redirect('/home');
        }
        }

        // ini lihat album
        public function lihatalbum ($AlbumID)
        {
            $bebas = Album::find($AlbumID);
            $bebas = Foto::where('AlbumID', $AlbumID)->get();
            return view('lihatalbum', compact ('bebas','bebas'));
        }

        // aksi like
        public function like($FotoID){
            $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
        
            if(!$cek){
                $data = new Like();
                $data->FotoID = $FotoID;
                $data->UserID = session('user')->UserID;
                $data->TanggalLike = now();
                $data->save();
        
                return redirect()->back();
            } else {
                $cek->delete();
                return redirect()->back();
            }
        }

        // ini aksi komentar
        public function barukomen(Request $request,$FotoID){

            $data = new Komentar;
            $data ->FotoID = $FotoID;
            $data ->UserID = session('user')->UserID;
            $data ->IsiKomentar = $request->input('komentar');
            $data ->TanggalKomentar= date ('Y-m-d H:i:s');

            $data -> save();

            return redirect()->back();
        }

        // ini aksi hapus album
    public function hapusdata($AlbumID){
        $bebas = Album::find($AlbumID);
        $bebas->delete();

        return redirect('/album');
    }
        //  ini edit album
        public function editbum($AlbumID){
            $item['album'] = Album::find($AlbumID);
            $bebas = Album::all();
            return view('editbum', compact('item','bebas'));
        }
        public function editAlbum(Request $request, $AlbumID){
            $data = Album::find($AlbumID);
            $data->NamaAlbum =$request->input('namaalbum');
            $data->Deskripsi =$request->input('deskripsialbum'); 
            $data->TanggalDibuat=  date('Y-m-d');
            $data->UserID =session('user')->UserID;
            $data->save(); 
            return redirect('/album');
        } 

            // ini untuk hapus foto
    public function hapusfoto($FotoID){
        $bebas = Foto::find($FotoID);
        $bebas->delete();

        return redirect('/lihatalbum');
    }
    // ini edit foto
    public function editdata($FotoID){
        $item['foto'] = Foto::find($FotoID);
        $bebas = Album::where('UserID', session('user')->UserID)->get();
        return view('edit', compact('item','bebas'));
    }
    public function editAksi(Request $request, $FotoID){
        if ($request->hasFile('lokasifile')) {
            $locate = $request->file('lokasifile')->store('public/images'); // tambahkan ini
        }
        $data = Foto::find($FotoID);
        $data->JudulFoto = $request->input('judulfoto');
        $data->DeskripsiFoto = $request->input('deskripsifoto');
        $data->TanggalUnggah = date ('Y-m-d');
        $data->LokasiFile = $locate;
        $data->AlbumID = $request->get('album');
        $data->UserID = session('user')->UserID;
        $data->save();
        return redirect('/lihatalbum');
    }    
}
